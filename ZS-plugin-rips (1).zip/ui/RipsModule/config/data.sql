INSERT INTO RIPS_SETTINGS
    (id, ui_url, api_url, username, password)
    VALUES
    (1, 'https://saas.ripstech.com', 'https://api-2.ripstech.com', '', '');
