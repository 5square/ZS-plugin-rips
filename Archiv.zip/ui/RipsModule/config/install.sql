CREATE TABLE RIPS_SETTINGS (
    id int NOT NULL,
    api_url varchar(255) NOT NULL,
    ui_url varchar(255) NOT NULL,
    username varchar(255) NOT NULL,
    password varchar(255) NOT NULL,
    PRIMARY KEY (id)
);
